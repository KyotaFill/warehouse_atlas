# Hướng dẫn dùng BPMN cho đồ án Warehouse Atlas

14/09/2026 · Dành cho người đang vẽ use case, class diagram và ERD.

## 1. BPMN bổ sung điều gì?

| Sơ đồ | Trả lời | Ví dụ |
|---|---|---|
| Use case | Ai cần đạt mục tiêu gì? | Nhân viên giữ hàng; quản lý ghi sổ |
| Class diagram | Lớp nào chịu trách nhiệm, có quan hệ/hành vi gì? | ReservationService gọi AllocationPolicy |
| ERD | Dữ liệu lưu ở đâu và ràng buộc thế nào? | stock_reservation gắn SO line và bucket |
| BPMN | Công việc bắt đầu thế nào, ai làm bước nào, rẽ nhánh/chờ/kết thúc ra sao? | Thiếu hàng thì dừng trước pick; commit chưa rõ thì đối chiếu |

BPMN là chuẩn mô hình quy trình riêng, không phải một loại UML class/use case diagram. Trong bộ này, một quy trình có thể dùng nhiều use case và lớp. Không cần vẽ một BPMN riêng cho mỗi nút giao diện hoặc tạo 35 quy trình chỉ để khớp 35 use case. Ký pháp và file XML đối chiếu [BPMN 2.0.2 của OMG](https://www.omg.org/spec/BPMN/2.0.2/).

## 2. Quy ước ký hiệu

| Thành phần | Đọc như thế nào? | Ví dụ có trong bộ |
|---|---|---|
| Pool | Participant ở phạm vi nghiệp vụ | Đơn vị vận hành kho; Nhà cung cấp; LLM local |
| Lane | Phân công bên trong pool | Nhân viên, Quản lý, Hệ thống Atlas |
| Start event | Điều kiện/sự kiện khởi đầu một lần xử lý | Yêu cầu xuất; thông tin hàng đến |
| End event | Kết thúc nhánh/lần xử lý theo mô hình | POSTED; chưa hoàn tất; UNKNOWN |
| User task | Con người thực hiện với hỗ trợ ứng dụng | Nhập phiếu; phê duyệt; đếm và nhập kết quả |
| Manual task | Công việc thủ công ngoài phần mềm | Đối chiếu hàng thực; lấy hàng theo danh sách |
| Service task | Phần mềm thực hiện tự động | Giữ hàng trong transaction; tính bổ sung |
| Call activity | Gọi một quy trình dùng lại; viền đậm | BP01 gọi BP03 để duyệt/ghi sổ |
| Exclusive gateway (XOR) | Chỉ đi một nhánh đúng ở mỗi lần qua | Có/không; POSTED/STALE/lỗi |
| Default flow | Đường mặc định nếu các nhánh điều kiện không đúng | Không/khác/chưa rõ |
| Sequence flow | Thứ tự công việc trong cùng pool | Nhập phiếu → kiểm/lưu |
| Message flow | Trao đổi giữa hai participant khác nhau | Thông tin NCC; gửi/nhận phản hồi LLM |
| Boundary error event | Tác vụ bị ngắt theo loại lỗi được xử lý | KnownRollback hoặc UnknownCommit ở ghi sổ |
| Boundary timer event | Tác vụ chờ bị ngắt khi hết thời gian | Timeout khi đợi model ở BP09 |
| Timer start event | Đến thời điểm tạo một lượt xử lý | Lượt kiểm tra reservation đến hạn |
| Loop marker | Lặp một activity theo điều kiện | Xác nhận từng pick stop |
| Sequential multi-instance | Lặp theo tập phần tử, lần lượt | Xử lý từng warehouse có hold đến hạn |
| Text annotation | Ghi chú, không mang token điều khiển | Giới hạn phạm vi dưới mỗi hình |

Không kéo sequence flow xuyên pool. Trong một pool, sequence flow được phép đi qua các lane. Không dùng message flow giữa “Nhân viên” và “Hệ thống” khi hai bên đang là lane của cùng participant.

Nhà cung cấp xuất hiện trong BPMN vì có trao đổi nghiệp vụ thực tế, dù chưa có tài khoản/cổng GUI nên không phải actor trực tiếp trong use case phần mềm v1. Pool nghiệp vụ không đồng nghĩa boundary phần mềm. Database, bảng và repository không được thêm thành “người thực hiện” chỉ để nối dây.

Các boundary event ở đây là interrupting: khi lỗi/timeout được bắt, nhánh bình thường của activity không tiếp tục trong lần thực thi đó. Error chỉ được catch theo contract adapter mô tả; UI phải phân biệt lỗi nghiệp vụ, rollback đã xác nhận và commit chưa rõ. Không gọi mọi lỗi là rollback.

## 3. Các quy trình trong bộ

| BP | Nội dung | Nên đọc để hiểu |
|---|---|---|
| BP01 | Nhập hàng theo đơn mua | Chỉ khi gọi BP03 trả POSTED mới tăng on_hand của lot/vị trí/condition nhận; DRAFT/APPROVED chưa tăng. |
| BP02 | Giữ hàng và xuất theo đơn | Reserve: reserved tăng, on_hand không đổi. Pick: không đổi lượng. Shipment POSTED: on_hand và reserved cùng giảm, consumed tăng, CONSUME và movement được ghi. |
| BP03 | Duyệt và ghi sổ phiếu — quy trình dùng chung | Tác động theo kind, chỉ trong commit ghi sổ. Cùng key đã thành công trả kết quả cũ; không ghi thêm movement. |
| BP04 | Kiểm kê và chốt chênh lệch | Mở/đếm không đổi on_hand. release_shortage chỉ giảm reserved. Finalize có delta thì movement điều chỉnh và đóng phiên cùng commit; delta = 0 chỉ đóng phiên. |
| BP05 | Chuyển vị trí hoặc đổi tình trạng hàng | Giảm nguồn, tăng đích; tổng lượng trong phạm vi doanh nghiệp giữ nguyên. Điều kiện cấp phát có thể thay đổi theo location/condition. |
| BP06 | Nhận khách trả hoặc trả nhà cung cấp | Khách trả: on_hand tăng ở QUARANTINE mặc định. Trả NCC: on_hand giảm ở nguồn. PO/SO không tự mở lại vì các phiếu trả. |
| BP07 | Lập lộ trình và xác nhận lấy hàng | Chỉ map/pick_run/pick_stop; không thay on_hand/reserved hoặc tạo movement. |
| BP08 | Đảo toàn bộ chứng từ đã ghi sổ | Movement mới đối ứng các movement gốc; gốc không sửa/xóa. Không khôi phục reservation đã tiêu thụ. |
| BP09 | Hỏi trợ lý kho với bằng chứng | Chỉ lưu hồ sơ AI và evidence; không tạo PO hoặc thay số lượng tồn. |
| BP10 | Đề xuất bổ sung và duyệt tạo PO nháp | PROPOSED chưa tạo PO. APPLIED và PO DRAFT cùng commit; không tăng tồn và chưa xác nhận đơn mua. |
| BP11 | Truy vết và khóa / mở khóa lô | BLOCK/UNBLOCK chỉ đổi trạng thái cấp phát và audit; on_hand giữ nguyên. Nhả hold là tác vụ riêng có xác nhận. |
| BP12 | Xử lý reservation đến hạn | Tăng released_qty, giảm balance.reserved, thêm EXPIRE; on_hand giữ nguyên. Clock vượt hạn chưa tự sinh tác động này. |

Bạn nên bắt đầu bằng BP01, mở tiếp BP03 để biết phần call activity làm gì, rồi BP02 và BP04. BP09/BP10 là hai hình tách riêng: trả lời bằng chứng khác với duyệt tạo PO. BP12 bổ sung cơ chế expiry mà người dùng thường dễ hiểu nhầm là tự thay đổi số dư khi đồng hồ qua hạn.

## 4. Thứ tự vẽ một quy trình

1. Chọn đúng một trigger và phạm vi một lần xử lý; viết tiền điều kiện và kết quả trước.
2. Tạo participant/lane theo trách nhiệm; đừng tạo lane theo bảng DB hoặc từng class.
3. Vẽ luồng thành công ngắn trước, dùng động từ cụ thể cho task.
4. Thêm XOR ở nơi đã có dữ liệu hoặc quyết định để chọn nhánh; gắn điều kiện loại trừ nhau và một nhánh mặc định.
5. Thêm nhánh sửa/để sau/thất bại/chưa rõ; ghi trạng thái thực giữ lại ở cuối nhánh.
6. Chỉ thêm timer/error/call/loop khi có ý nghĩa nghiệp vụ. Bộ này không dùng parallel gateway vì chưa có cặp công việc bắt buộc chạy độc lập cần đồng bộ; không thêm dấu cộng chỉ để hình phức tạp hơn.
7. Đối chiếu mỗi task với use case, service và tác động dữ liệu. Kiểm token có tới end, hoặc quay lại/chờ có chủ đích; không có task rơi rớt.

XOR merge chỉ hợp các đường loại trừ nhau, không chờ nhiều nhánh. Nếu sau này thêm parallel split, phải xét join và việc một nhánh đi vào end sớm có làm nhánh khác chờ vô hạn hay không.

## 5. Phân biệt transaction DB và transaction BPMN

Trong Atlas, tác vụ “Ghi sổ nguyên tử” gọi một service có transaction PostgreSQL. Không vẽ một BPMN transaction subprocess viền đôi chỉ vì code có BEGIN/COMMIT. BPMN transaction/cancel/compensation có ngữ nghĩa riêng; không phải ký hiệu thay thế cho rollback của SQL.

BP04 chốt kiểm kê gọi `PostingEngine.post_in` trong UoW của `StocktakeService.finalize`; nó không gọi BP03 để tách thành hai lần commit. BP08 đảo cũng tạo/duyệt/post trong một service. Tái dùng code engine không bắt buộc trở thành call activity nghiệp vụ.

Khi lỗi xảy ra sau một task thủ công, rollback database không đưa hàng về kệ hoặc thu hồi hàng đã giao. Đây là lý do END “chưa hoàn tất” phải đi kèm công việc xử lý hiện trường nếu đã lấy hàng thực tế.

## 6. Trạng thái phải giữ khớp database

| Đối tượng | Trạng thái cần dùng | Không suy diễn |
|---|---|---|
| Phiếu kho | DRAFT, APPROVED, POSTED, CANCELLED | Không thêm PENDING_APPROVAL/REJECTED vào schema hiện có |
| PO/SO | DRAFT, CONFIRMED, CLOSED, CANCELLED | Nhận/giao một phần là số liệu suy ra, không tự thêm state |
| Stocktake | DRAFT, COUNTING, REVIEW, POSTED, CANCELLED | Kết thúc nhánh lỗi chưa chắc nhả freeze |
| PickRun | PLANNED, IN_PROGRESS, DONE, CANCELLED | Stale là kết quả so hash, không thêm STALE vào DB |
| AIProposal | PROPOSED, APPLIED, REJECTED, STALE | APPLIED chỉ cùng commit có PO DRAFT |
| StockReservation | allocated/consumed/released; remaining tính ra | Không có status column; hết giờ chưa tự giảm reserved |

`POSTED` có thể là tên end event và trạng thái phiếu; đó là hai khái niệm khác nhau. Service cập nhật DB trước; end chỉ biểu diễn kết quả quy trình. `UNKNOWN`, `NOT_APPLIED`, `DEFERRED` trong mô hình là kết quả ứng dụng, không thêm vào DocumentStatus.

## 7. Đối chiếu use case: phần có hình và phần ngoài phạm vi hình

| Use case | Vị trí trong BPMN |
|---|---|
| UC01–02 đăng nhập/tài khoản | Tiền điều kiện và kiểm quyền chung; chưa cần một BP riêng |
| UC03–05 danh mục/kho/đối tác | Master và nguồn cung làm tiền điều kiện; đây không phải 12 quy trình CRUD |
| UC06 đơn mua | Tiền điều kiện BP01; PO DRAFT đầu ra BP10 cần xác nhận qua UC06 |
| UC07 | BP01 |
| UC08–09 | BP03 dùng chung |
| UC10 đơn xuất | Tiền điều kiện BP02 |
| UC11 | BP02; đầu vào BP07; cấp lại sau BP11 là thao tác riêng |
| UC12 | BP11; nhả giữ do thiếu kiểm kê có scope BP04; kỹ thuật expiry BP12 |
| UC13 | BP02 |
| UC14–15 | BP05 |
| UC16–18 | BP04 |
| UC19–20 | BP06 |
| UC21 | BP08 |
| UC22 báo cáo | Dữ liệu hỗ trợ các quyết định; chưa vẽ luồng tra cứu riêng |
| UC23–24 | BP11 |
| UC25 replay | Công cụ điều tra/đối chiếu; chưa vẽ quy trình riêng |
| UC26 map | Tiền điều kiện BP07 |
| UC27–28 | BP07, được BP02 gọi khi dùng tính năng P1 |
| UC29 | BP09 |
| UC30–32 | BP10; UC30 rule có thể chạy độc lập với AI |
| UC33 audit/đối soát | Công cụ hỗ trợ nhánh lỗi/UNKNOWN; chưa vẽ luồng báo cáo riêng |
| UC34 what-if | P2, chưa thêm vào bộ quy trình cốt lõi này |
| UC35 tồn đầu | Chuẩn bị OPENING DRAFT theo UC35 rồi có thể dùng BP03; không dùng BP01 như phiếu nhận theo PO |

Việc use case nằm ngoài các hình chính không có nghĩa bị bỏ khỏi kế hoạch. BPMN này chọn các quy trình có chuyển vai trò, state hoặc tác động kho đáng giải thích.

## 8. Giao việc cho agent từ BPMN

| Bạn cần chốt | Agent cần hiện thực |
|---|---|
| Ý nghĩa từng nhánh | Enum/outcome và AppError rõ, không gộp UNKNOWN vào FAILED |
| Task nào người thực hiện | View/presenter, loading, validation, confirm và trạng thái khi quay lại |
| Task nào tự động | Service theo class diagram; input/output DTO và quyền |
| Điểm ghi dữ liệu | UoW/transaction, locking, audit, idempotency đúng contract |
| Timer/call/error | Adapter/worker xử lý theo thiết kế; không yêu cầu nhúng BPMN engine để có các tính năng này |
| Kết quả nghiệp vụ | Test theo các ca trong đặc tả, kiểm qua DB bằng transaction thực |

Prompt mẫu:

> Triển khai task BP03_post và các outcome theo BPMN/class diagram. Chỉ public InventoryService.post_document mở UoW; PostingEngine và repository không commit. Xử lý POSTED replay, validation chắc chắn không ghi, KnownRollback và UnknownCommit riêng. Cùng request giữ document_id/key. Test rollback giữa chừng, double-click/retry, tổng nhiều dòng cùng bucket và block lot sau draft. Chưa sửa schema/state hoặc làm UI ngoài contract DTO.

## 9. Câu hỏi để bảo vệ

- Vì sao PO đã CONFIRMED vẫn chưa tăng tồn?
- Vì sao BP01 gọi BP03 nhưng BP04 không gọi BP03 để ghi adjustment?
- Sau end “để sau”, phiếu và hold còn ở trạng thái nào?
- Tại sao đã pick đủ vẫn có thể bị từ chối post shipment?
- Lỗi commit chưa rõ khác với rollback đã biết ở điểm nào?
- Nhà cung cấp là participant BPMN nhưng chưa là actor GUI vì sao?
- Khi nào dùng message flow, khi nào dùng sequence flow qua lane?
- Nếu LLM timeout, token đi nhánh nào và DB kho có thay đổi không?
- Vì sao xử lý expiry cần transaction dù đã có expires_at?
- Một BPMN đẹp cần chứng minh được các quy tắc nào bằng code/test?
