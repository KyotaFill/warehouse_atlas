# Bộ BPMN Warehouse Atlas — cách mở và sử dụng

Phiên bản 1.0 · 14/09/2026. Bổ sung cho use case, class diagram và database đã thiết kế. Bộ này mô tả quy trình; chưa triển khai phần mềm hay workflow engine.

## Chọn file

| File | Dùng khi nào? |
|---|---|
| `warehouse_atlas_bpmn.bpmn` | Mô hình đầy đủ: 12 process, 12 collaboration, 12 diagram có bố cục |
| `warehouse_atlas_bpmn.xml` | Nội dung giống hệt bản .bpmn, tiện chọn trong hộp thoại chỉ lọc XML |
| `warehouse_atlas_bp01.bpmn` … `warehouse_atlas_bp12.bpmn` | Mở từng sơ đồ chính riêng |
| `warehouse_atlas_bp01.svg` … `warehouse_atlas_bp12.svg` | Hình vector để phóng to hoặc chèn báo cáo |
| Các bản PNG BP01, BP03, BP04, BP09, BP10 | Xem nhanh các quy trình tiêu biểu; nền trắng, rộng 1800 px |
| `warehouse_atlas_dac_ta_bpmn.md` | Trigger, điều kiện, từng task/gateway, trách nhiệm lớp, bảng liên quan, tác động tồn và ca nghiệm thu |
| `warehouse_atlas_huong_dan_bpmn.md` | Ký hiệu, cách vẽ, ánh xạ use case, liên hệ OOP/DB, câu hỏi bảo vệ |
| `warehouse_atlas_kiem_tra_bpmn.md` | Kết quả kiểm tra thực tế và giới hạn kiểm chứng |

## Mở trong Visual Paradigm Desktop

Theo [tài liệu nhập BPMN 2.0 chính thức của Visual Paradigm](https://www.visual-paradigm.com/support/documents/vpuserguide/124/2193/57198_importingbpm.html): chọn **Project → Import → BPMN 2.0**, chọn file XML, rồi xác nhận import. Với bộ này, dùng `warehouse_atlas_bpmn.xml` để nhập đầy đủ. Đây là đường dẫn menu được tài liệu Desktop mô tả; không khẳng định VP Online có cùng menu hay tính năng ở mọi gói.

Nên nhập một bản master vào project mới hoặc bản sao project trước khi ghép. Không nhập đồng thời cả master, XML alias và mọi standalone vào cùng project: chúng dùng lại cùng ID mô hình. VP nêu rằng việc nhập lại mô hình đã sửa có thể ghi đè thay đổi ở mô hình hiện tại.

Nếu công cụ chỉ hiển thị một diagram mặc định, chọn diagram khác trong danh sách model, hoặc mở bản `bpXX.bpmn` tương ứng. Mỗi standalone có thêm định nghĩa process được call tới để không có tham chiếu thiếu, nhưng chỉ chứa bố cục của BP chính. Muốn xem chi tiết BP03/BP07, mở bản tương ứng hoặc master. Hình SVG là bản xem tĩnh, không thay thế mô hình BPMN có task/gateway để chỉnh sửa.

## Lộ trình đọc đề xuất

1. **BP01 → BP03:** nhập hàng và phần duyệt/ghi sổ được tái sử dụng. Nhận rõ thời điểm on_hand thay đổi.
2. **BP02:** giữ hàng, lấy hàng và ghi sổ xuất; giải thích vì sao ba bước có tác động khác nhau.
3. **BP04:** kiểm kê, đếm lại, xử lý actual nhỏ hơn reserved và chốt nguyên tử.
4. **BP05, BP06, BP08, BP11, BP12:** chuyển, trả, đảo, xử lý lô và hết hạn giữ.
5. **BP07, BP09, BP10:** lộ trình lấy hàng, trợ lý bằng chứng và đề xuất mua có người duyệt.

BP03 có call activity từ các luồng nhập/xuất/chuyển/trả. BP04 không gọi BP03 để ghi một adjustment ở transaction riêng: `StocktakeService.finalize` tái dùng posting engine bên trong cùng Unit of Work. BPMN biểu diễn nghiệp vụ; việc dùng lại code không buộc phải vẽ call activity.

## Khi giao cho đội agent

Chốt input/output/outcome của từng task trước khi agent code. XML đặt `isExecutable=false`; điều kiện gateway là văn bản mô tả, chưa có FEEL/Python binding. Các mã Error và timer là hợp đồng cần triển khai, không phải chức năng tự có sau import. Timer 30 giây, tối đa 6 lượt AI và lịch 1 phút là cấu hình minh họa.

Ca nghiệm thu trong đặc tả là đầu bài test cho ứng dụng tương lai. Các kiểm tra trong bộ hiện tại chỉ xác minh XML, tham chiếu, đường đi và khả năng hiển thị; chưa chạy các giao dịch Tkinter/PostgreSQL hay kiểm thử import trực tiếp trong VP.

## Nguồn chuẩn và công cụ kiểm tra

- [OMG BPMN 2.0.2](https://www.omg.org/spec/BPMN/2.0.2/): đặc tả và schema XML chính thức.
- [bpmn-js](https://bpmn.io/toolkit/bpmn-js/): trình đọc/hiển thị dùng để kiểm tra và xuất SVG.
- [Visual Paradigm — Importing BPMN 2.0](https://www.visual-paradigm.com/support/documents/vpuserguide/124/2193/57198_importingbpm.html): hướng dẫn menu nhập và lưu ý nhập lại mô hình.
