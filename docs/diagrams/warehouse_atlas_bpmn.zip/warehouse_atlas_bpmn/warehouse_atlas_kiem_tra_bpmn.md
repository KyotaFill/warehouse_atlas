# Kết quả kiểm tra bộ BPMN

14/09/2026 · Áp dụng cho các file trong cùng gói phiên bản 1.0.

## Đã thực hiện

- Kiểm XML bằng bộ XSD chính thức của OMG: tất cả 13 file .bpmn và bản .xml alias đều đạt.
- Kiểm ID không trùng; sequence flow có hai đầu trong cùng process; mỗi node thuộc đúng một lane; khai báo incoming/outgoing khớp cạnh thực tế.
- Kiểm XOR rẽ nhánh có một default và điều kiện trên các nhánh còn lại; không có task vô tình tách nhánh song song.
- Kiểm boundary event gắn đúng activity, không có sequence flow đi vào; mô hình dùng interrupting boundary.
- Kiểm message flow nối hai participant khác nhau; các call activity trỏ đến process có trong file, không gọi đệ quy.
- Kiểm có đường từ start đến mọi node và từ mỗi node đến ít nhất một end; tính cả đường lỗi phát sinh từ activity sang boundary event.
- Nhập và xuất SVG cho 12 standalone bằng bpmn-js; mở được cả 12 diagram của master; không có cảnh báo import/open.
- Xuất PNG và kiểm hình tiêu biểu để sửa font tiếng Việt, nền, nhãn và đường nối.
- Kiểm bản master .bpmn và .xml có nội dung byte giống hệt nhau.

## Thống kê master

12 process, 12 collaboration, 12 diagram, 156 flow node và 154 sequence flow. Số node của các standalone có thể lớn hơn hình nhìn thấy vì chứa thêm định nghĩa process được call; các định nghĩa dùng chung không được tính lặp trong master.

| File | Process | Diagram | Schema | Cấu trúc |
|---|---:|---:|---|---|
| warehouse_atlas_bp01.bpmn | 2 | 1 | Đạt | Đạt |
| warehouse_atlas_bp02.bpmn | 3 | 1 | Đạt | Đạt |
| warehouse_atlas_bp03.bpmn | 1 | 1 | Đạt | Đạt |
| warehouse_atlas_bp04.bpmn | 1 | 1 | Đạt | Đạt |
| warehouse_atlas_bp05.bpmn | 2 | 1 | Đạt | Đạt |
| warehouse_atlas_bp06.bpmn | 2 | 1 | Đạt | Đạt |
| warehouse_atlas_bp07.bpmn | 1 | 1 | Đạt | Đạt |
| warehouse_atlas_bp08.bpmn | 1 | 1 | Đạt | Đạt |
| warehouse_atlas_bp09.bpmn | 1 | 1 | Đạt | Đạt |
| warehouse_atlas_bp10.bpmn | 1 | 1 | Đạt | Đạt |
| warehouse_atlas_bp11.bpmn | 1 | 1 | Đạt | Đạt |
| warehouse_atlas_bp12.bpmn | 1 | 1 | Đạt | Đạt |
| warehouse_atlas_bpmn.bpmn | 12 | 12 | Đạt | Đạt |
| warehouse_atlas_bpmn.xml | 12 | 12 | Đạt | Đạt |

## Giới hạn

Đây là kiểm tra tĩnh và khả năng hiển thị, không phải chứng minh mọi execution trace kết thúc hay chứng nhận thực thi BPMN. Các vòng sửa dữ liệu, đếm lại và gọi model có chủ đích; việc kết thúc phụ thuộc contract triển khai.

Chưa kiểm thử import bằng ứng dụng Visual Paradigm thực tế. Định dạng được đối chiếu chuẩn BPMN 2.0 và hướng dẫn nhập của VP; phần mềm đích có thể bố trí nhãn hoặc trình bày diagram khác.

Chưa có ứng dụng để chạy test concurrency, rollback, phân quyền, freeze hay số dư. Các ca đó được nêu trong đặc tả để đội code triển khai và chứng minh sau này.
