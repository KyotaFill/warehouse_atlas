# Đặc tả quy trình BPMN — Warehouse Atlas

Bổ sung 1.0 · 14/09/2026 · Bám kế hoạch/database, 35 use case và bộ class diagram trước đó.

Đây là mô hình quy trình để phân tích, vẽ và triển khai đồ án Tkinter. Các process đặt `isExecutable=false`: chưa có workflow engine, chưa có biến chạy hay service binding. Điều kiện trong XML là mô tả nghiệp vụ; không phải SQL, FEEL hoặc Python đã được triển khai. Không tạo bảng/state mới trong bộ này.

## Phạm vi và cách đọc

Mỗi BP mô tả một loại lần xử lý. Một PO có thể có nhiều lần nhận BP01; một SO có thể có nhiều lần xuất BP02. Kết thúc BPMN instance không tự đóng toàn bộ đơn hoặc xóa phiếu đang chờ. Các tên END như POSTED/UNKNOWN mô tả kết quả phải trả và hiển thị, không phải thao tác gán biến tự động của engine.

Pool chính đại diện đơn vị vận hành kho, gồm người và phần mềm. Lane “Hệ thống Atlas” chứa tác vụ tự động, các lane người chứa việc thực hiện/ra quyết định. ADMIN không mặc nhiên có quyền nghiệp vụ kho. Các lane là phân công mẫu; khi quản lý được phép kiêm việc nhân viên, vẫn kiểm đúng quyền ở service. Không bắt buộc người lập khác người duyệt trong baseline hiện tại.

Một user task có tương tác form chỉ hoàn tất khi người dùng và API xác nhận kết quả hợp lệ. Lỗi field/permission/version có thể giữ người ở chính task để sửa/đọc lại. Các gateway sau service phân nhánh theo outcome đã xác định; không dùng gateway để tạo ra dữ liệu mà service chưa tính. Không vẽ tất cả lỗi kỹ thuật phổ biến lặp lại ở mỗi task; nguyên tắc lỗi chung bên dưới vẫn áp dụng.

## Bảo đảm chung

1. Phiên/quyền kiểm lại tại service; không dựa riêng việc nút có hiện trên UI.
2. DRAFT và APPROVED chưa có movement. Chỉ ghi sổ thành công mới cập nhật ledger/balance; reserve/release có sự kiện lượng giữ riêng.
3. GUI, lời nhắc xác nhận, đếm bằng người, tính route dài và chờ LLM không nằm trong transaction ghi kho kéo dài.
4. Khóa ghi theo chuẩn warehouse→document/order headers→location→lot→balance→reservation. Chuyển liên kho khóa các kho theo UUID; tạo bucket mới phải được xử lý đúng dưới khóa.
5. Bất biến `0 <= reserved <= on_hand` kiểm trên delta đã gộp. Một dòng phiếu POSTED có đúng một movement.
6. Lỗi trước commit được xác nhận rollback thì không có thay đổi dở dang. Mất liên lạc khi commit là UNKNOWN cho đến khi đối chiếu đủ; không biến “chưa thấy bản ghi” thành bằng chứng chắc chắn chưa ghi.
7. Cùng request post dùng lại document_id/key; reserve chưa có request log tổng quát nên không retry mù một lệnh giữ một phần. Với proposal, retry dựa proposal_id và PO đã liên kết.
8. Khi kết thúc nhánh “để sau/chưa hoàn tất”, giữ trạng thái DB thực. End event không tự nhả hold, nhả freeze hoặc đổi phiếu thành CANCELLED.
9. Mỗi tác vụ DB có UoW/Session riêng theo worker; UI chỉ nhận DTO và cập nhật ở Tk main thread.
10. Những thao tác thủ công ngoài máy (kiểm hàng, lấy hàng) không tự đảo ngược khi DB rollback. Cần xử lý hiện trường theo chứng từ/thực tế; v1 chưa có mô hình đầy đủ cho bàn đóng gói/vận tải.

## Các mã kết quả mô tả

| Kết quả | Ý nghĩa nghiệp vụ |
|---|---|
| POSTED | Commit ghi sổ được xác nhận hoặc đúng kết quả cũ đã được đọc lại |
| NOT_APPLIED | Đã xác nhận không có tác động mới của lần ghi; phiếu giữ state thực |
| DEFERRED | Người dùng để sau; không tự sửa document status |
| UNKNOWN | Chưa xác định được kết quả commit; cần đối chiếu/retry an toàn |
| DONE (pick) | Checklist và kế hoạch hợp lệ đã hoàn tất; chưa có shipment movement |
| RESERVED_SHORTAGE | Khi kiểm kê, actual nhỏ hơn reserved; cần manager chọn lượng hold để xử lý |
| APPLIED / STALE (proposal) | Giá trị đúng enum ai_proposal; APPLIED đi cùng PO DRAFT |

Các boundary error được đặt tên KnownRollback, UnknownCommit và PlanInvalid là hợp đồng adapter/service cần hiện thực khi code; không phải khẳng định đã có exception class hoặc BPMN engine runtime. “Lỗi” không tự đồng nghĩa rollback đã biết. Timer 30 giây, 6 vòng AI và lịch 1 phút là thông số minh họa, cần quyết định cấu hình thực sau thử nghiệm.

## BP01 — Nhập hàng theo đơn mua

**Use case:** UC07, UC08, UC09; UC06 là tiền điều kiện.

**Tiền điều kiện:** PO CONFIRMED còn lượng nhận; SKU/UOM/kho/vị trí và phiên hợp lệ.

**Kết quả thành công:** RECEIPT POSTED tăng tồn đúng lot/location/condition; PO cập nhật lượng nhận hiệu lực qua truy vấn.

**Lớp chịu trách nhiệm:** DocumentService; gọi BP03 → InventoryService.

**Dữ liệu liên quan:** purchase_order/line; lot; inventory_document/line; posting qua BP03.

**Tác động tồn:** Chỉ khi gọi BP03 trả POSTED mới tăng on_hand của lot/vị trí/condition nhận; DRAFT/APPROVED chưa tăng.

**Giới hạn:** Nhận vào RECEIVING chưa cấp phát được; putaway qua quy trình BP05. Một lần chạy xử lý một lần nhận, có thể là một phần PO. Thông tin NCC là trao đổi ngoài ứng dụng, không ngụ ý có API/email tích hợp.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP01_start | Message start event / Nhân viên kho | Có thông tin hàng đến | Thông tin giao hàng/phiếu giao nhận đến qua kênh thực tế; nhân viên tiếp nhận. Không phải một API đã triển khai. |
| BP01_check | Manual task / Nhân viên kho | Đối chiếu hàng, PO và tình trạng | Đếm/kiểm hàng thực tế; PO phải đúng nguồn và còn lượng nhận. |
| BP01_draft | User task / Nhân viên kho | Nhập lượng, lot, hạn và vị trí | Lưu form đủ dữ liệu; thiếu/sai trường giữ tại bước nhập. UC07; DocumentService.save_draft; lot chưa mang số dư. |
| BP01_save | Service task / Hệ thống Atlas | Kiểm tra và lưu RECEIPT DRAFT | Kiểm quy đổi, SKU-lot, hạn và phần còn nhận dự kiến; lưu draft, chưa tạo movement. |
| BP01_valid | Exclusive gateway (XOR) / Hệ thống Atlas | Lưu hợp lệ? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP01_fix | User task / Nhân viên kho | Xem lỗi và sửa dữ liệu | Lỗi field/nguồn nhận được giải thích, không thay tồn. |
| BP01_approve | Call activity / Quản lý kho | Duyệt và ghi sổ phiếu | Gọi quy trình BP03, truyền document_id; manager chịu trách nhiệm duyệt. Không mở transaction khi chờ người. Gọi process BP03; target có trong master và bản standalone. |
| BP01_result | Exclusive gateway (XOR) / Hệ thống Atlas | Kết quả gọi? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP01_done | End event / Nhân viên kho | Đã ghi nhận hàng nhập | outcome=POSTED; phiếu và số dư có thể drill-down. |
| BP01_pending | End event / Quản lý kho | Chưa hoàn tất ghi sổ | Giữ trạng thái thực từ quy trình BP03; UNKNOWN không được kết luận chưa commit. Theo dõi lại cùng phiếu/key. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| valid | approve | Có (saved = true) |
| valid | fix | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| fix | draft | Quay lại sau khi hoàn tất task |
| result | done | POSTED (outcome = POSTED) |
| result | pending | Khác / chưa rõ — nhánh mặc định, khi không nhánh điều kiện nào đúng |

Message flow qua ranh giới participant:

- supplier → start: Thông tin giao hàng / chứng từ nguồn.

### Ca nghiệm thu khi triển khai

- Nhận 2 thùng × 48: DRAFT không đổi tồn; POSTED tăng 96 đúng bucket.
- Hai phiếu nháp cùng nhận phần cuối PO: lúc post không cho tổng vượt đơn.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

## BP02 — Giữ hàng và xuất theo đơn

**Use case:** UC11, UC13, UC08, UC09; UC27–28 tùy chọn; UC10 là tiền điều kiện.

**Tiền điều kiện:** SO CONFIRMED còn nhu cầu; người dùng có quyền.

**Kết quả thành công:** SHIPMENT POSTED giảm on_hand và reserved, tăng consumed, thêm CONSUME và movement cùng transaction.

**Lớp chịu trách nhiệm:** ReservationService, DocumentService; gọi BP07/BP03.

**Dữ liệu liên quan:** sales_order/line; stock_balance; stock_reservation; reservation_event; inventory_document/line; pick_run/stop khi P1.

**Tác động tồn:** Reserve: reserved tăng, on_hand không đổi. Pick: không đổi lượng. Shipment POSTED: on_hand và reserved cùng giảm, consumed tăng, CONSUME và movement được ghi.

**Giới hạn:** Mặc định giữ đủ hoặc không giữ. Pick chỉ là checklist; v1 chưa có sổ riêng cho hàng chuyển ra bàn đóng gói. Nếu post bị chặn sau pick, phải xử lý hàng vật lý theo tình huống; không tự coi là đã giao.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP02_start | Start event / Nhân viên kho | Cần thực hiện đơn xuất | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP02_request | User task / Nhân viên kho | Chọn đơn và lượng cần giữ | UC11; chỉ gửi phần nhu cầu còn cần; không cho UI tự chọn hàng bị cấm. |
| BP02_reserve | Service task / Hệ thống Atlas | Khóa, kiểm FEFO/FIFO và giữ hàng | ReservationService.reserve: kiểm SO/active/block/hạn/freeze; lock theo chuẩn; all-or-nothing; reservation, reserved, ALLOCATE cùng commit. |
| BP02_held | Exclusive gateway (XOR) / Hệ thống Atlas | Giữ thành công? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP02_short | End event / Quản lý kho | Thiếu hàng / cần xử lý | Báo thiếu cụ thể; không giữ một phần ngầm. Nếu timeout chưa rõ, tải lại holds và nhu cầu trước khi thao tác tiếp. |
| BP02_route | Exclusive gateway (XOR) / Nhân viên kho | Dùng lộ trình P1? | Lựa chọn tính năng đã triển khai; không đổi lot để có đường ngắn hơn. |
| BP02_pick | Call activity / Nhân viên kho | Lập và thực hiện kế hoạch lấy hàng |  Gọi process BP07; target có trong master và bản standalone. |
| BP02_manual | Manual task / Quản lý kho | Lấy hàng theo danh sách đã giữ | Quản lý có quyền vận hành. Lane này phân công mẫu; có thể giao nhân viên kho theo cùng quyền. Không tạo movement. |
| BP02_pickok | Exclusive gateway (XOR) / Hệ thống Atlas | Đã lấy đủ, đúng hàng? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP02_pickfail | End event / Quản lý kho | Chưa thể lập phiếu xuất | Hold vẫn có vòng đời riêng; không tự nhả vì kết thúc lần xử lý. |
| BP02_draft | User task / Nhân viên kho | Lập SHIPMENT DRAFT | UC13: lưu SO line + product/lot/location/condition; chưa có FK draft line→reservation. |
| BP02_approve | Call activity / Quản lý kho | Duyệt và ghi sổ phiếu |  Gọi process BP03; target có trong master và bản standalone. |
| BP02_posted | Exclusive gateway (XOR) / Hệ thống Atlas | Kết quả gọi? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP02_done | End event / Nhân viên kho | Đã ghi sổ xuất hàng | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP02_pending | End event / Quản lý kho | Chưa hoàn tất xuất | Không khẳng định hàng đã giao chỉ từ việc đã pick hoặc phiếu APPROVED. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| held | route | Có (reservation_result = SUCCEEDED) |
| held | short | Không / chưa rõ — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| route | pick | Có (use_route = true) |
| route | manual | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| pickok | draft | Có (pick_result = DONE) |
| pickok | pickfail | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| posted | done | POSTED (outcome = POSTED) |
| posted | pending | Khác / chưa rõ — nhánh mặc định, khi không nhánh điều kiện nào đúng |

### Ca nghiệm thu khi triển khai

- Tồn 10, hai yêu cầu giữ 7: một thành công, một thiếu 4; không giữ 3 ngầm.
- Đã giữ/pick nhưng lô vừa BLOCKED: post phải kiểm lại và bị chặn.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

## BP03 — Duyệt và ghi sổ phiếu — quy trình dùng chung

**Use case:** UC08, UC09; SF01/SF02.

**Tiền điều kiện:** Phiếu DRAFT hoặc APPROVED; có dòng hợp lệ; manager có quyền.

**Kết quả thành công:** outcome=POSTED chỉ khi commit được xác nhận hoặc đọc lại đúng kết quả đã commit.

**Lớp chịu trách nhiệm:** DocumentService, InventoryService, PostingEngine, UnitOfWork.

**Dữ liệu liên quan:** inventory_document/line; stock_movement; stock_balance; stock_reservation; reservation_event; audit_event; master và orders để kiểm.

**Tác động tồn:** Tác động theo kind, chỉ trong commit ghi sổ. Cùng key đã thành công trả kết quả cũ; không ghi thêm movement.

**Giới hạn:** Đây là quy trình nghiệp vụ, không phải transaction BPMN. Transaction PostgreSQL chỉ nằm trong tác vụ Ghi sổ nguyên tử. DRAFT/APPROVED chưa đổi tồn; END không tự thay status. Không dùng compensation event để mô tả rollback DB.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP03_start | Start event / Hệ thống Atlas | Nhận yêu cầu xử lý phiếu | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP03_state | Exclusive gateway (XOR) / Hệ thống Atlas | Phiếu ở trạng thái nào? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP03_review | User task / Quản lý kho | Xem phiếu và quyết định | Manager xem nội dung + expected_version; kiểm quyền tại service; không có PENDING_APPROVAL trong DB. |
| BP03_decision | Exclusive gateway (XOR) / Quản lý kho | Quyết định? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP03_fix | User task / Nhân viên kho | Sửa và lưu lại DRAFT | Chỉ sửa phiếu DRAFT. Nếu đã APPROVED, phải DocumentService.return_to_draft trước; không cho sửa nội dung đã post. |
| BP03_stop | End event / Nhân viên kho | Dừng; giữ phiếu nháp | outcome=DEFERRED; kết thúc lần xử lý này, không đổi document thành CANCELLED. |
| BP03_approve | User task / Quản lý kho | Phê duyệt đúng phiên bản | DocumentService.approve kiểm version/quyền. Task hoàn thành khi API xác nhận APPROVED; conflict thì tải lại, xem và quyết định lại trong task. |
| BP03_confirm | User task / Quản lý kho | Xác nhận tác động ghi sổ | Kết thúc hộp thoại trước khi mở transaction; giữ idempotency_key khi retry cùng hành động. |
| BP03_post | Service task / Hệ thống Atlas | Ghi sổ nguyên tử hoặc trả kết quả cũ | InventoryService.post_document → PostingEngine.post_in: warehouse→headers→location→lot→balance→reservation; kiểm live; gộp delta; movement/balance/hold/events/audit/POSTED cùng commit. |
| BP03_business | Exclusive gateway (XOR) / Hệ thống Atlas | Kết quả nghiệp vụ? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP03_ok | End event / Hệ thống Atlas | POSTED đã được xác nhận | outcome=POSTED; trạng thái đã đọc/commit chắc chắn. |
| BP03_blocked | End event / Quản lý kho | Bị chặn; chưa ghi mới | outcome=NOT_APPLIED; lô block, thiếu hàng, freeze, version/key conflict hoặc validation đã được xử lý và xác nhận không có lần ghi mới. |
| BP03_rollback | Boundary error event / Hệ thống Atlas | Lỗi đã rollback | Chỉ bắt lỗi mà adapter xác nhận transaction không commit. Gắn vào task `post`; interrupting, không có sequence flow đi vào event. |
| BP03_knownfail | End event / Nhân viên kho | Lỗi; không có thay đổi dở dang | outcome=NOT_APPLIED; giữ trạng thái trước post, thường APPROVED. |
| BP03_unknown | Boundary error event / Hệ thống Atlas | Chưa rõ commit | Ví dụ mất kết nối khi commit/nhận phản hồi; không được suy diễn rollback. Gắn vào task `post`; interrupting, không có sequence flow đi vào event. |
| BP03_lookup | Service task / Hệ thống Atlas | Tra cứu / retry cùng key, có giới hạn | Mở transaction mới; tra kết quả hoặc gọi lại cùng document/key. Không xác nhận thất bại chỉ vì SELECT tạm thời chưa thấy hàng; phải phân biệt transaction còn đang xử lý. |
| BP03_resolved | Exclusive gateway (XOR) / Hệ thống Atlas | Đã xác định kết quả? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP03_uncertain | End event / Quản lý kho | UNKNOWN — cần đối chiếu tiếp | outcome=UNKNOWN; giữ correlation/key; không tạo yêu cầu ghi mới với key khác, không bàn giao như đã hoàn tất. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| state | review | DRAFT (status = DRAFT) |
| state | confirm | APPROVED (status = APPROVED) |
| state | lookup | POSTED / cần đối chiếu — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| decision | approve | Duyệt (decision = APPROVE) |
| decision | fix | Cần sửa (decision = REWORK) |
| decision | stop | Để sau — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| fix | review | Quay lại sau khi hoàn tất task |
| business | ok | POSTED (post_result = POSTED) |
| business | blocked | Từ chối — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| rollback | knownfail | Lỗi/sự kiện tương ứng phát sinh |
| unknown | lookup | Lỗi/sự kiện tương ứng phát sinh |
| resolved | ok | Đã ghi (resolved = POSTED) |
| resolved | blocked | Chắc chắn chưa ghi (resolved = NOT_APPLIED) |
| resolved | uncertain | Chưa rõ — nhánh mặc định, khi không nhánh điều kiện nào đúng |

### Ca nghiệm thu khi triển khai

- Cùng key/payload ghi lần hai trả phiếu cũ; số movement không tăng.
- Mất phản hồi commit đi nhánh UNKNOWN; không báo chắc chắn rollback.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

## BP04 — Kiểm kê và chốt chênh lệch

**Use case:** UC16, UC17, UC18.

**Tiền điều kiện:** Vị trí lá active; manager có quyền mở/chốt; lot của hàng phát hiện ngoài snapshot được xác minh.

**Kết quả thành công:** Phiên POSTED; nếu có delta thì adjustment và tồn cùng commit; freeze được kết thúc.

**Lớp chịu trách nhiệm:** StocktakeService, PostingEngine.post_in, UnitOfWork.

**Dữ liệu liên quan:** stocktake/line; location; stock_balance; reservations/events; adjustment document/line; movement; audit.

**Tác động tồn:** Mở/đếm không đổi on_hand. release_shortage chỉ giảm reserved. Finalize có delta thì movement điều chỉnh và đóng phiên cùng commit; delta = 0 chỉ đóng phiên.

**Giới hạn:** COUNTING/REVIEW là freeze nghiệp vụ. Chốt chỉ dùng PostingEngine trong cùng UoW, không gọi quy trình BP03 để commit adjustment riêng. Đếm0 khác chưa đếm; chi tiết expected bị bỏ khỏi DTO màn đếm.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP04_start | Start event / Quản lý kho | Cần kiểm kê một vị trí | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP04_select | User task / Quản lý kho | Chọn vị trí và mở phiên | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP04_snapshot | Service task / Hệ thống Atlas | Khóa ngắn, chụp tồn và COUNTING | StocktakeService.start: kiểm chưa có phiên active, chụp expected, frozen_at rồi commit. |
| BP04_opened | Exclusive gateway (XOR) / Hệ thống Atlas | Mở phiên thành công? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP04_noopen | End event / Quản lý kho | Không mở phiên mới | Không tạo hai snapshot active; nếu kết quả chưa rõ phải tra phiên active trước khi thử lại. |
| BP04_count | User task / Nhân viên kho | Đếm mù, nhập đủ và gửi kết quả | Task bao gồm việc đếm thực tế và nhập qua UI; lần đầu counted, lần sau recounted nếu manager yêu cầu. Hàng không thấy nhập0; thiếu dòng thì task chưa hoàn thành. |
| BP04_review | User task / Quản lý kho | Xem số đếm và chênh lệch | Sau lần gửi hợp lệ trạng thái REVIEW; lấy recount nếu có. Không tự cho người đếm thấy expected trước khi nộp. |
| BP04_decision | Exclusive gateway (XOR) / Quản lý kho | Quyết định? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP04_recount | User task / Quản lý kho | Yêu cầu đếm lại | Cho phép UC17 ghi recounted theo quyền; giữ REVIEW/freeze; không ghi đè counted ban đầu. |
| BP04_cancel | Service task / Hệ thống Atlas | Hủy phiên và kết thúc freeze | StocktakeService.cancel dưới khóa/version: CANCELLED, audit, không adjustment. Chỉ hoàn tất khi commit xác nhận. |
| BP04_cancelled | End event / Hệ thống Atlas | Phiên CANCELLED | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP04_finalize | Service task / Hệ thống Atlas | Chốt kiểm kê trong một transaction | StocktakeService.finalize: lock/check snapshot, reserved và reason. Delta0 chỉ đóng phiên; delta khác0 tạo/duyệt ADJUSTMENT và dùng engine.post_in; đóng POSTED + audit cùng commit. |
| BP04_result | Exclusive gateway (XOR) / Hệ thống Atlas | Kết quả chốt? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP04_done | End event / Hệ thống Atlas | POSTED; tồn khớp số đã duyệt | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP04_shortage | User task / Quản lý kho | Chọn hold thiếu cần nhả | Chỉ khi actual<reserved; manager chọn rõ lượng/hold, có lý do. Không tự nhả toàn bộ giữ hàng. |
| BP04_release | Service task / Hệ thống Atlas | Nhả hold trong đúng phiên REVIEW | StocktakeService.release_shortage: exception freeze có scope được xác minh, cập nhật reservation/event/reserved và audit; không đổi on_hand. Task xong khi commit xác nhận; lỗi giữ REVIEW. |
| BP04_blocked | End event / Nhân viên kho | Chưa chốt; xử lý nguyên nhân | Khi đã xác nhận chưa áp dụng thì phiên vẫn REVIEW/freeze. Không báo này nếu commit chưa rõ. |
| BP04_uncertain | Boundary error event / Hệ thống Atlas | Chưa rõ commit |  Gắn vào task `finalize`; interrupting, không có sequence flow đi vào event. |
| BP04_unknownend | End event / Quản lý kho | Tra lại phiên trước khi xử lý tiếp | Không kết luận freeze còn hay hết khi commit chưa rõ; tải trạng thái theo stocktake_id/key. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| opened | count | Có (opened = true) |
| opened | noopen | Không / chưa rõ — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| decision | finalize | Chấp nhận (decision = ACCEPT) |
| decision | recount | Đếm lại (decision = RECOUNT) |
| decision | cancel | Hủy — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| result | done | POSTED (result = POSTED) |
| result | shortage | Thiếu so với hold (result = RESERVED_SHORTAGE) |
| result | blocked | Lỗi đã xác định — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| release | review | Quay lại sau khi hoàn tất task |
| uncertain | unknownend | Lỗi/sự kiện tương ứng phát sinh |

### Ca nghiệm thu khi triển khai

- Expected = 10, counted = 0 phải là delta = -10 sau duyệt, khác NULL chưa đếm.
- Lỗi adjustment làm phiên vẫn REVIEW; delta = 0 đóng phiên mà không sinh movement lượng 0.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

## BP05 — Chuyển vị trí hoặc đổi tình trạng hàng

**Use case:** UC14, UC15, UC08, UC09.

**Tiền điều kiện:** Xác định SKU/lot, ô nguồn/đích, lượng và lý do.

**Kết quả thành công:** Phiếu TRANSFER/RECLASSIFY POSTED; các bucket thay đổi đúng hướng; tổng lượng toàn phạm vi bảo toàn.

**Lớp chịu trách nhiệm:** DocumentService; gọi BP03.

**Dữ liệu liên quan:** location, lot, inventory_document/line; stock_movement, stock_balance khi post.

**Tác động tồn:** Giảm nguồn, tăng đích; tổng lượng trong phạm vi doanh nghiệp giữ nguyên. Điều kiện cấp phát có thể thay đổi theo location/condition.

**Giới hạn:** TRANSFER v1 chỉ lấy phần chưa giữ; RECLASSIFY kiểm điều kiện theo hướng. Chuyển liên kho cần khóa cả hai kho; v1 không mô hình hóa vận tải đầy đủ.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP05_start | Start event / Nhân viên kho | Cần di chuyển / phân loại lại | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP05_kind | User task / Nhân viên kho | Chọn loại phiếu, nguồn và đích | TRANSFER giữ lot/condition; RECLASSIFY đổi condition có lý do, không tự biến hàng hỏng thành GOOD không căn cứ. |
| BP05_save | Service task / Hệ thống Atlas | Kiểm và lưu phiếu DRAFT | DocumentService.save_draft; chưa đổi balance. Kiểm nguồn != đích, lượng chuẩn dương và các FK. |
| BP05_valid | Exclusive gateway (XOR) / Hệ thống Atlas | Dữ liệu hợp lệ? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP05_fix | User task / Nhân viên kho | Xem lỗi và sửa phiếu | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP05_approve | Call activity / Quản lý kho | Duyệt và ghi sổ phiếu |  Gọi process BP03; target có trong master và bản standalone. |
| BP05_result | Exclusive gateway (XOR) / Hệ thống Atlas | Kết quả gọi? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP05_done | End event / Nhân viên kho | Đã ghi chuyển / đổi tình trạng | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP05_pending | End event / Quản lý kho | Chưa hoàn tất; xem kết quả chi tiết | Theo bảo đảm chung và trạng thái trả về của bước trước. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| valid | approve | Có (saved = true) |
| valid | fix | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| fix | kind | Quay lại sau khi hoàn tất task |
| result | done | POSTED (outcome = POSTED) |
| result | pending | Khác / chưa rõ — nhánh mặc định, khi không nhánh điều kiện nào đúng |

### Ca nghiệm thu khi triển khai

- Chuyển 3 từ A sang B bảo toàn tổng; phần held không bị lấy để chuyển.
- Đổi GOOD→QUARANTINE làm available giảm nhưng không làm mất tổng vật lý.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

## BP06 — Nhận khách trả hoặc trả nhà cung cấp

**Use case:** UC19, UC20, UC08, UC09.

**Tiền điều kiện:** Có chứng từ nguồn POSTED, nhận diện đúng lot, còn lượng được trả và quyền phù hợp.

**Kết quả thành công:** Phiếu trả POSTED; hàng khách trả tăng QUARANTINE mặc định, hàng trả NCC giảm đúng bucket.

**Lớp chịu trách nhiệm:** DocumentService; gọi BP03.

**Dữ liệu liên quan:** original documents/lines, lot, balance; return documents/lines và movement khi post.

**Tác động tồn:** Khách trả: on_hand tăng ở QUARANTINE mặc định. Trả NCC: on_hand giảm ở nguồn. PO/SO không tự mở lại vì các phiếu trả.

**Giới hạn:** Trả một phần là nghiệp vụ vật lý, khác REVERSAL toàn phiếu. Trả không tự mở lại PO/SO; tổng trả phải được kiểm lại khi post, không chỉ lúc lập nháp. Không tự gán lot nếu chưa xác định nguồn.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP06_start | Start event / Nhân viên kho | Có yêu cầu trả hàng | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP06_choose | User task / Nhân viên kho | Chọn hướng trả và chứng từ nguồn | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP06_load | Service task / Hệ thống Atlas | Tính lượng còn trả và tồn hiện tại | CUSTOMER_RETURN dựa shipment; SUPPLIER_RETURN dựa receipt; net các reversal của phiếu trả, không cộng ABS mọi movement. |
| BP06_valid | Exclusive gateway (XOR) / Hệ thống Atlas | Nguồn và lượng hợp lệ? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP06_blocked | End event / Quản lý kho | Cần xác minh nguồn / xử lý lượng | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP06_draft | User task / Nhân viên kho | Nhập lượng, tình trạng và lưu DRAFT | Khách trả giữ lot gốc, mặc định QUARANTINE; NCC trả đúng nguồn, không lấy phần held. Lô block có thể đi luồng trả có kiểm soát. |
| BP06_approve | Call activity / Quản lý kho | Duyệt và ghi sổ phiếu trả |  Gọi process BP03; target có trong master và bản standalone. |
| BP06_result | Exclusive gateway (XOR) / Hệ thống Atlas | Kết quả gọi? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP06_done | End event / Nhân viên kho | Đã ghi sổ trả hàng | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP06_pending | End event / Quản lý kho | Chưa hoàn tất; giữ căn cứ nguồn | Theo bảo đảm chung và trạng thái trả về của bước trước. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| valid | draft | Có (return_valid = true) |
| valid | blocked | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| result | done | POSTED (outcome = POSTED) |
| result | pending | Khác / chưa rõ — nhánh mặc định, khi không nhánh điều kiện nào đúng |

### Ca nghiệm thu khi triển khai

- Đã ship 20, tổng trả hiệu lực không vượt 20 kể cả hai người thao tác.
- Khách trả 2 QUARANTINE không tăng available và không tự mở lại SO.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

## BP07 — Lập lộ trình và xác nhận lấy hàng

**Use case:** UC27, UC28; UC26 và UC11 là tiền điều kiện.

**Tiền điều kiện:** Có hold đủ/đúng cho phần đơn định lấy, graph đã khai báo và điểm tiếp cận hợp lệ.

**Kết quả thành công:** PickRun DONE và checklist đủ; không tạo movement hoặc giảm on_hand/reserved.

**Lớp chịu trách nhiệm:** PickService, RoutePlanner, MapRepository.

**Dữ liệu liên quan:** map_node/edge; stock_reservation; pick_run/stop; lot/balance/order để kiểm.

**Tác động tồn:** Chỉ map/pick_run/pick_stop; không thay on_hand/reserved hoặc tạo movement.

**Giới hạn:** FEFO chọn lot trước; route chỉ thay thứ tự ghé. So baseline cùng tập stop; không hứa tối ưu toàn cục. STALE là kết quả kiểm hash, không thêm vào PickStatus.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP07_start | Start event / Nhân viên kho | Cần lấy phần hàng đã giữ | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP07_request | User task / Nhân viên kho | Chọn hold và điểm đầu / cuối | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP07_compute | Service task / Hệ thống Atlas | Chụp đầu vào và tính đường | PickService/RoutePlanner: snapshot ngắn, tính ngoài transaction dài; shortest paths + heuristic, giữ baseline nếu heuristic kém. |
| BP07_reachable | Exclusive gateway (XOR) / Hệ thống Atlas | Các điểm đều tới được? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP07_noroute | End event / Nhân viên kho | Không có lộ trình hợp lệ | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP07_save | Service task / Hệ thống Atlas | Kiểm lại hash và lưu kế hoạch | Lock/check graph, hold và điều kiện; lưu pick_run/pick_stop PLANNED khi đầu vào còn đúng. |
| BP07_fresh | Exclusive gateway (XOR) / Hệ thống Atlas | Đầu vào còn đúng? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP07_pick | User task / Nhân viên kho | Lấy và xác nhận từng điểm | Mỗi lượt dùng PickService.confirm_stop với tổng picked_qty; kiểm input_hash/hold/lot hiện tại. Task lặp trong cùng kế hoạch, không phải lặp shipment. Lặp chuẩn: còn điểm cần xác nhận. |
| BP07_stale | Boundary error event / Nhân viên kho | Kế hoạch đã đổi |  Gắn vào task `pick`; interrupting, không có sequence flow đi vào event. |
| BP07_check | Service task / Hệ thống Atlas | Kiểm đủ checklist và đặt DONE | Chỉ khi trạng thái/đầu vào vẫn hợp lệ; nếu chưa đủ task chưa hoàn tất. Không ghi stock movement. |
| BP07_done | End event / Nhân viên kho | DONE — đủ checklist | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP07_replan | End event / Hệ thống Atlas | Cần lập kế hoạch mới | outcome=BLOCKED; giữ snapshot lịch sử; kiểm và xử lý holds riêng, không âm thầm đổi lot. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| reachable | save | Có (all_reachable = true) |
| reachable | noroute | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| fresh | pick | Có (input_unchanged = true) |
| fresh | replan | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| stale | replan | Lỗi/sự kiện tương ứng phát sinh |

### Ca nghiệm thu khi triển khai

- Đóng một cạnh làm hash đổi; kế hoạch cũ bị từ chối trước xác nhận.
- Xác nhận lại cùng picked_qty_total không cộng đôi, không trừ tồn.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

## BP08 — Đảo toàn bộ chứng từ đã ghi sổ

**Use case:** UC21.

**Tiền điều kiện:** Phiếu gốc POSTED, chưa đảo; đủ quyền/lý do và điều kiện nguồn hiện tại.

**Kết quả thành công:** REVERSAL POSTED có movement đối ứng; chứng từ gốc vẫn POSTED và lịch sử còn nguyên.

**Lớp chịu trách nhiệm:** InventoryService.reverse, PostingEngine.post_in.

**Dữ liệu liên quan:** original documents/lines/movements; reversal documents/lines/movements; balances; audit.

**Tác động tồn:** Movement mới đối ứng các movement gốc; gốc không sửa/xóa. Không khôi phục reservation đã tiêu thụ.

**Giới hạn:** Không gọi quy trình BP03 để tách commit tạo reversal. InventoryService.reverse tạo/duyệt/ghi trong cùng UoW. Không hoàn tác giao hàng thực tế, không khôi phục reservation cũ ngầm.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP08_start | Start event / Quản lý kho | Cần sửa tác động hồ sơ | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP08_select | User task / Quản lý kho | Chọn phiếu gốc và nhập lý do | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP08_preview | Service task / Hệ thống Atlas | Dựng tác động đảo và các phụ thuộc | Kiểm sơ bộ lượng, downstream, reversal đã có; preview không khóa lâu hoặc bảo đảm tương lai. |
| BP08_possible | Exclusive gateway (XOR) / Hệ thống Atlas | Có phương án đảo hợp lệ? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP08_blocked | End event / Quản lý kho | Không thể đảo ở hiện tại | Ví dụ nhập100 đã dùng70, còn30 thì không đảo trừ100; trả NCC30 là quy trình06. |
| BP08_confirm | User task / Quản lý kho | Xác nhận toàn bộ tác động đảo | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP08_reverse | Service task / Hệ thống Atlas | Khóa, kiểm lại và ghi REVERSAL nguyên tử | InventoryService.reverse + PostingEngine.post_in. Reversal_of_id unique và key giữ nguyên khi retry; kiểm đủ điều kiện hiện tại, không sửa gốc. |
| BP08_result | Exclusive gateway (XOR) / Hệ thống Atlas | Đã xác nhận ghi thành công? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP08_done | End event / Quản lý kho | Đã ghi chứng từ đảo | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP08_error | End event / Hệ thống Atlas | Bị chặn / rollback đã xác nhận | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP08_uncertain | Boundary error event / Hệ thống Atlas | Chưa rõ commit |  Gắn vào task `reverse`; interrupting, không có sequence flow đi vào event. |
| BP08_lookup | End event / Quản lý kho | Đối chiếu reversal và key | Tra reversal_of_id/key trước khi retry; không tạo phiếu đảo khác để thử. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| possible | confirm | Có (possible = true) |
| possible | blocked | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| result | done | Có (reverse_result = POSTED) |
| result | error | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| uncertain | lookup | Lỗi/sự kiện tương ứng phát sinh |

### Ca nghiệm thu khi triển khai

- Nhập100 đã dùng70: không thể đảo toàn bộ100 khi chỉ còn30.
- Đảo shipment hợp lệ không làm reservation đã consumed tự sống lại.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

## BP09 — Hỏi trợ lý kho với bằng chứng

**Use case:** UC29.

**Tiền điều kiện:** Phiên còn hiệu lực; dữ liệu/tool có quyền; model local được cấu hình.

**Kết quả thành công:** Câu trả lời có evidence, ID, đơn vị và as_of, hoặc lý do chưa trả lời được; không tự ghi tồn/PO.

**Lớp chịu trách nhiệm:** AssistantService, LLMPort/OllamaAdapter, ToolGateway.

**Dữ liệu liên quan:** ai_run, ai_tool_call; các truy vấn nghiệp vụ chỉ trong phạm vi quyền.

**Tác động tồn:** Chỉ lưu hồ sơ AI và evidence; không tạo PO hoặc thay số lượng tồn.

**Giới hạn:** LLM là participant hỗ trợ ngoài ứng dụng Atlas dù chạy cùng máy. Thời hạn chờ 30 giây và tối đa 6 vòng là cấu hình minh họa, cần chốt sau khi thử trên máy thật. Không giữ transaction kho khi chờ model.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP09_start | Start event / Người dùng (NV / QL) | Cần hỏi dữ liệu kho | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP09_question | User task / Người dùng (NV / QL) | Nhập câu hỏi và phạm vi | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP09_prepare | Service task / Hệ thống Atlas | Kiểm phiên, quyền và chuẩn bị ngữ cảnh | AssistantService: thiếu SKU/kho thì yêu cầu làm rõ trong task nhập; chỉ đưa tool schema và dữ liệu được phép. |
| BP09_send | Send task / Hệ thống Atlas | Gửi ngữ cảnh / kết quả tool | OllamaAdapter qua LLMPort; tăng bộ đếm vòng, đặt request correlation. |
| BP09_receive | Receive task / Hệ thống Atlas | Chờ phản hồi model | Nhận đúng correlation; hủy chờ/timeout không tạo tác động kho. |
| BP09_timeout | Boundary timer event / Hệ thống Atlas | Hết thời gian chờ |  Gắn vào task `receive`; interrupting, không có sequence flow đi vào event. |
| BP09_stop | End event / Người dùng (NV / QL) | Chưa trả lời được / đã timeout | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP09_response | Exclusive gateway (XOR) / Hệ thống Atlas | Loại phản hồi? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP09_tools | Service task / Hệ thống Atlas | Kiểm và thực hiện tool cho phép | ToolGateway kiểm tên/schema/quyền trước query; giữ evidence; tool bị từ chối trả lỗi có cấu trúc, không SQL/shell tùy ý. |
| BP09_rounds | Exclusive gateway (XOR) / Hệ thống Atlas | Còn lượt gọi model? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP09_verify | Service task / Hệ thống Atlas | Kiểm số liệu và dẫn evidence | Không lấy con số model tự bịa làm dữ kiện. Không đủ evidence thì trả lời giới hạn/chưa xác nhận. |
| BP09_show | Service task / Hệ thống Atlas | Hiển thị câu trả lời có căn cứ | Lưu ai_run/ai_tool_call; UI nhận DTO qua queue. Tạo đề xuất mua là quy trình10 và chỉ manager được áp dụng. |
| BP09_done | End event / Người dùng (NV / QL) | Đã trả lời; chưa tạo PO | Theo bảo đảm chung và trạng thái trả về của bước trước. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| timeout | stop | Lỗi/sự kiện tương ứng phát sinh |
| response | tools | Yêu cầu tool (response_kind = TOOL_REQUEST) |
| response | verify | Câu trả lời (response_kind = FINAL) |
| response | stop | Sai cấu trúc — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| rounds | send | Có (rounds_used < 6) |
| rounds | stop | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |

Message flow qua ranh giới participant:

- send → llm: Ngữ cảnh / kết quả tool.
- llm → receive: Phản hồi theo lượt gọi.

### Ca nghiệm thu khi triển khai

- Operator hỏi giá vốn: tool không được truy lấy phần dữ liệu ngoài quyền.
- Model timeout/đề nghị tool không hợp lệ không treo Tkinter và không ghi kho.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

## BP10 — Đề xuất bổ sung và duyệt tạo PO nháp

**Use case:** UC30, UC31, UC32; nối từ UC29.

**Tiền điều kiện:** Manager có quyền; AI proposal cần ai_run nguồn hợp lệ; policy và nguồn cung được xác định.

**Kết quả thành công:** Một proposal APPLIED tạo đúng một PO DRAFT, liên kết result_purchase_order_id cùng commit.

**Lớp chịu trách nhiệm:** ReplenishmentService, AssistantService, ProposalService, OrderRepository.

**Dữ liệu liên quan:** reorder_policy, supplier_product, orders/balance; analysis_run, replenishment_suggestion, ai_proposal; purchase_order/line, audit.

**Tác động tồn:** PROPOSED chưa tạo PO. APPLIED và PO DRAFT cùng commit; không tăng tồn và chưa xác nhận đơn mua.

**Giới hạn:** Tạo đề xuất chưa đặt mua hoặc tăng tồn. UC30 có thể chạy rule độc lập; không cần LLM để tính lượng. Phiếu PO cần xác nhận riêng qua UC06. STALE không được thay số mới và duyệt ngầm.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP10_start | Start event / Quản lý kho | Tạo mới hoặc mở đề xuất | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP10_choose | User task / Quản lý kho | Chọn proposal có sẵn / tạo mới | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP10_existing | Exclusive gateway (XOR) / Hệ thống Atlas | Có proposal để mở? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP10_compute | Service task / Hệ thống Atlas | Tính bổ sung từ snapshot và policy | ReplenishmentService.compute: eligible_on_hand + inbound_hợp_lệ − open_demand; không trừ reserved hai lần; MOQ/bội số, evidence. |
| BP10_enough | Exclusive gateway (XOR) / Hệ thống Atlas | Đủ căn cứ và cần mua? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP10_none | End event / Quản lý kho | Không cần mua / thiếu dữ kiện | Không tạo suggestion qty0 hoặc gán NCC tùy ý. |
| BP10_propose | Service task / Hệ thống Atlas | Lưu proposal PROPOSED và input_hash | AssistantService.propose_purchase kiểm payload theo schema và ai_run nguồn; chưa có PO. |
| BP10_review | User task / Quản lý kho | Xem lượng, nguồn cung, giá và căn cứ | Mở proposal có sẵn cũng đi vào bước này; nếu đã APPLIED hiển thị PO cũ, không có nút tạo mới từ cùng proposal. |
| BP10_decision | Exclusive gateway (XOR) / Quản lý kho | Quyết định? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP10_reject | Service task / Hệ thống Atlas | Lưu REJECTED nếu còn PROPOSED | ProposalService.reject dưới khóa; không ghi đè APPLIED khi có race. |
| BP10_rejected | End event / Hệ thống Atlas | Đã xử lý từ chối | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP10_later | End event / Quản lý kho | Để sau; giữ trạng thái hiện tại | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP10_apply | Service task / Hệ thống Atlas | Khóa, kiểm lại và tạo PO DRAFT nguyên tử | ProposalService.apply: kiểm quyền, hash/đầu vào hiện tại; APPLIED trả PO cũ; PROPOSED hợp lệ tạo PO/lines + APPLIED + result + audit cùng commit. |
| BP10_result | Exclusive gateway (XOR) / Hệ thống Atlas | Kết quả áp dụng? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP10_done | End event / Quản lý kho | Có PO DRAFT để xem | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP10_stale | End event / Hệ thống Atlas | STALE — cần đề xuất mới | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP10_failed | End event / Quản lý kho | Chưa áp dụng; xem nguyên nhân | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP10_unknown | Boundary error event / Hệ thống Atlas | Chưa rõ commit |  Gắn vào task `apply`; interrupting, không có sequence flow đi vào event. |
| BP10_lookup | End event / Hệ thống Atlas | Tra proposal và PO đã liên kết | Không tạo PO mới khi chưa rõ kết quả; retry theo proposal_id, APPLIED trả cùng PO. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| existing | review | Có (existing_proposal = true) |
| existing | compute | Tạo mới — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| enough | propose | Có (can_propose = true) |
| enough | none | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| decision | apply | Duyệt (decision = APPLY) |
| decision | reject | Từ chối (decision = REJECT) |
| decision | later | Để sau — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| result | done | APPLIED (result = APPLIED) |
| result | stale | STALE (result = STALE) |
| result | failed | Lỗi đã xác định — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| unknown | lookup | Lỗi/sự kiện tương ứng phát sinh |

### Ca nghiệm thu khi triển khai

- Apply cùng proposal hai lần trả cùng PO; APPLIED không tồn tại nếu PO rollback.
- Input thay đổi: STALE, yêu cầu xem đề xuất mới, không duyệt con số mới ngầm.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

## BP11 — Truy vết và khóa / mở khóa lô

**Use case:** UC23, UC24, UC12; UC11 là thao tác cấp lại riêng.

**Tiền điều kiện:** Xác định đúng SKU và tất cả lot nội bộ thuộc phạm vi; manager có căn cứ.

**Kết quả thành công:** Trạng thái lô được ghi có audit; danh sách hàng/đơn bị ảnh hưởng rõ ràng; holds chỉ đổi khi có thao tác nhả.

**Lớp chịu trách nhiệm:** TraceabilityService, ReservationService.

**Dữ liệu liên quan:** lot; lịch sử documents/movements/partners; stock_reservation/events; stock_balance; audit.

**Tác động tồn:** BLOCK/UNBLOCK chỉ đổi trạng thái cấp phát và audit; on_hand giữ nguyên. Nhả hold là tác vụ riêng có xác nhận.

**Giới hạn:** Khóa không xóa on_hand, không tự nhả hold. Mở khóa vẫn phải xét expiry/condition/freeze. Không tự gửi thông báo đến khách/NCC trong phạm vi này.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP11_start | Start event / Quản lý kho | Có căn cứ xử lý lô | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP11_select | User task / Quản lý kho | Chọn SKU, mã lô và phạm vi | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP11_trace | Service task / Hệ thống Atlas | Truy nguồn, tồn và các đơn liên quan | TraceabilityService.trace_lot: nhiều lot nội bộ có thể cùng manufacturer_lot_code; phân biệt đã từng giao và lượng ròng chưa trả. |
| BP11_confirm | User task / Quản lý kho | Chọn BLOCK / UNBLOCK và lý do | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP11_change | Service task / Hệ thống Atlas | Khóa row lot, đổi trạng thái và audit | TraceabilityService.block_lots: transaction chỉ lot và audit; không đi ngược lấy warehouse sau lot. Task xong khi commit xác nhận. |
| BP11_holds | Exclusive gateway (XOR) / Hệ thống Atlas | Có hold cần xử lý? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP11_review | User task / Quản lý kho | Chọn nhả các hold bị ảnh hưởng | Quản lý có thể giữ nguyên để xử lý sau; không giả định unblock đồng nghĩa mọi hold hợp lệ. |
| BP11_decision | Exclusive gateway (XOR) / Quản lý kho | Nhả ngay? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP11_release | Service task / Hệ thống Atlas | Nhả lượng được chọn theo transaction | ReservationService.release theo chuẩn khóa; freeze thông thường chặn nhả, cần luồng kiểm kê có quyền nếu thích hợp. |
| BP11_result | Exclusive gateway (XOR) / Hệ thống Atlas | Nhả đã xác nhận? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP11_done | End event / Quản lý kho | Đã xử lý; cấp lại qua UC11 | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP11_pending | End event / Hệ thống Atlas | Giữ danh sách cần xử lý tiếp | Trạng thái lô đã được lưu; holds có thể còn nguyên. Nếu release chưa rõ, tải lại trước thao tác tiếp. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| holds | review | Có (affected_holds = true) |
| holds | done | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| decision | release | Có (release_now = true) |
| decision | pending | Để sau — nhánh mặc định, khi không nhánh điều kiện nào đúng |
| result | done | Có (release_confirmed = true) |
| result | pending | Không / chưa rõ — nhánh mặc định, khi không nhánh điều kiện nào đúng |

### Ca nghiệm thu khi triển khai

- Block lô còn77 không làm on_hand giảm77; holds hiện có vẫn cần xử lý riêng.
- Unblock lô đã hết hạn vẫn không cấp phát được.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

## BP12 — Xử lý reservation đến hạn

**Use case:** Luồng kỹ thuật hỗ trợ UC11, UC12, UC09; không phải UC người dùng mới.

**Tiền điều kiện:** Worker nội bộ được cấu hình; danh tính/audit rõ; dùng cùng cơ chế khóa/freeze.

**Kết quả thành công:** Hold đủ điều kiện hết hạn có released_qty tăng, reserved giảm và EXPIRE được ghi cùng transaction.

**Lớp chịu trách nhiệm:** ReservationService.expire_due, worker nội bộ.

**Dữ liệu liên quan:** stock_reservation; reservation_event; stock_balance; location/stocktake để kiểm freeze; audit.

**Tác động tồn:** Tăng released_qty, giảm balance.reserved, thêm EXPIRE; on_hand giữ nguyên. Clock vượt hạn chưa tự sinh tác động này.

**Giới hạn:** Timer minh họa mỗi phút, không có nghĩa đã cài lịch. Clock vượt expires_at chưa tự nhả giữ. Ô freeze được bỏ qua để xử lý ở lượt sau, không tự vượt quyền kiểm kê.

### Các bước và điểm quyết định

| ID trong mô hình | Loại / lane | Nội dung | Contract triển khai |
|---|---|---|---|
| BP12_start | Timer start event / Hệ thống Atlas | Đến lịch xử lý hold | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP12_find | Service task / Hệ thống Atlas | Tìm hold đến hạn theo kho | Chọn remaining>0; đọc ứng viên chưa phải nhả thành công; xử lý dưới khóa phải kiểm lại expires_at/current state. |
| BP12_any | Exclusive gateway (XOR) / Hệ thống Atlas | Có ứng viên? | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP12_none | End event / Hệ thống Atlas | Không có hold cần xử lý | Theo bảo đảm chung và trạng thái trả về của bước trước. |
| BP12_expire | Service task / Hệ thống Atlas | Xử lý lần lượt từng kho đủ điều kiện | ReservationService.expire_due: UoW mới cho mỗi kho, kiểm freeze, khóa/recheck, tăng released, giảm reserved, EXPIRE/audit cùng commit. Lỗi một kho rollback kho đó và ghi kết quả để lượt sau xử lý. Multi-instance tuần tự: số kho có ứng viên. |
| BP12_summary | Service task / Hệ thống Atlas | Ghi số đã nhả, bỏ qua và lỗi | Không cộng expired trên đồng hồ thành số đã nhả; chỉ lấy kết quả commit xác nhận. |
| BP12_done | End event / Hệ thống Atlas | Kết thúc lượt xử lý | Theo bảo đảm chung và trạng thái trả về của bước trước. |

### Nhánh và điểm quay lại

| Từ | Đến | Điều kiện / cách đi |
|---|---|---|
| any | expire | Có (candidate_count > 0) |
| any | none | Không — nhánh mặc định, khi không nhánh điều kiện nào đúng |

### Ca nghiệm thu khi triển khai

- Đã quá expires_at nhưng worker chưa commit: reserved chưa tự giảm.
- Ô đang COUNTING/REVIEW bị bỏ qua; khi xử lý hợp lệ chỉ sinh lượng EXPIRE còn active.

Các ca này là yêu cầu kiểm thử ứng dụng tương lai, không phải kết quả test của bộ BPMN.

